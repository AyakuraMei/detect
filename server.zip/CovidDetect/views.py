from datetime import date
from typing import final
from django import http
from django.db import models
from django.db.models.fields import json
from django.shortcuts import render
from django.http import HttpResponse
from django.urls.conf import path
from django.utils.datastructures import MultiValueDictKeyError
from django.views import View
from .models import Picture, User
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import json
import os
import hashlib
import random
# model loading
import torch
import torchvision
import cv2
import numpy as np
from PIL import Image
# Create your views here.

# request body is a dict

class analysis:
    def __init__(self, image_name) -> None:
        self.model = torchvision.models.resnet18(pretrained=True)
        self.model.eval()
        self.model.fc = torch.nn.Linear(in_features=512, out_features=3)
        self.model_CKPT = torch.load(
            './model_pth/resnet18_model_1e-5_epoch_8.pth', map_location=torch.device('cpu'))
        self.model.load_state_dict(self.model_CKPT['state_dict'])
        self.tf = torchvision.transforms.Compose([
            torchvision.transforms.Resize(size=(224, 224)),
            torchvision.transforms.ToTensor(),
            torchvision.transforms.Normalize(
                mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        self.class_name = ['normal', 'viral', 'COVID']
        self.image = image_name

    def analysis_image(self):
        image = self.tf(Image.open(self.image).convert('RGB')).unsqueeze(0)
        output = self.model(image)
        _, pred = torch.max(output, 1)
        percent = torch.nn.functional.softmax(output, dim=1)[0]
        return self.class_name[int(pred.cpu().numpy())], float(percent.max())

    # grad_cam
    def get_feature(self, image_uuid):
        def image_process(img_in):
            img = img_in.copy()
            img = img[:, :, ::-1]
            img = np.ascontiguousarray(img)
            tf = torchvision.transforms.Compose([
                torchvision.transforms.ToTensor(),
                torchvision.transforms.Normalize(
                    [0.4948052, 0.48568845, 0.44682974], [
                        0.24580306, 0.24236229, 0.2603115]
                )
            ])
            img = tf(img)
            img = img.unsqueeze(0)
            return img
        fmap_block = []
        grad_block = []
        
        def backward_hook(module, grad_in, grad_out):
            grad_block.append(grad_out[0].detach())
        def forward_hook(module, input, output):
            fmap_block.append(output)
        
        def cam_show_img(img, feature_map, grads):
                H, W, _ = img.shape
                cam = np.zeros(feature_map.shape[1:], dtype=np.float32)		# 4
                grads = grads.reshape([grads.shape[0],-1])					# 5
                weights = np.mean(grads, axis=1)							# 6
                for i, w in enumerate(weights):
                    cam += w * feature_map[i, :, :]							# 7
                cam = np.maximum(cam, 0)
                cam = cam / cam.max()
                cam = cv2.resize(cam, (W, H))

                heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
                cam_img = 0.3 * heatmap + 0.7 * img
                return cam_img

        img_cv = cv2.imread(self.image, 1)
        img_input = image_process(img_cv)

        self.model.layer4[1].conv2.register_forward_hook(forward_hook)
        self.model.layer4[1].conv2.register_backward_hook(backward_hook)
        output = self.model(img_input)
        model_tmp = self.model
        self.model.zero_grad()
        idx = np.argmax(output.cpu().data.numpy())
        class_loss = output[0, idx]
        class_loss.backward()

        grads_val = grad_block[0].cpu().data.numpy().squeeze()
        fmap = fmap_block[0].cpu().data.numpy().squeeze()
        cam_img = cam_show_img(img_cv, fmap, grads_val)
        feature_img = Image.fromarray(np.uint8(cam_img))
        feature_img.save('./PhotoDatabase/feature/' + str(image_uuid) + '_cv2.png')
        self.model = model_tmp

def check_login(request):
    res = {
        'success': True,
        'status': 1,
        'Description': 'wo ye shi long',
    }
    return HttpResponse(json.dumps(res), content_type="application/json")


def user_is_exist(request):
    def user_register(username, password):
        salt = random.sample('abcdefghijklmnopqrstuvwxyz', 6)
        final_password = str(hashlib.sha256((str(hashlib.sha256(password.encode(
            'utf-8')).hexdigest()) + ''.join(salt)).encode('utf-8')).hexdigest())
        userQuery = User.objects.create(
            name=username, password=final_password, salt=''.join(salt))

    data = json.loads(request.body)
    username = data['username']
    password = data['password']
    is_register = data['isRegister']
    isExist = User.objects.filter(name=username)
    if isExist.exists():
        if is_register == 1:
            res = {
                'Description': 'This user already registered.',
                'status': False,
            }
            return HttpResponse(json.dumps(res), content_type="application/json")
        elif is_register == 0:
            salt = isExist[0].salt
            pw = str(hashlib.sha256((str(hashlib.sha256(password.encode(
                'utf-8')).hexdigest()) + ''.join(salt)).encode('utf-8')).hexdigest())
            if isExist.filter(password=pw).exists():
                res = {
                    'status': True,
                }
                return HttpResponse(json.dumps(res), content_type="application/json")
            else:
                res = {
                    'Description': 'Password Error.',
                    'status': False,
                }
                return HttpResponse(json.dumps(res), content_type="application/json")
    else:
        if is_register == 1:
            user_register(username, password)
            res = {
                'Description': 'Register Successfully.',
                'status': True,
            }
            return HttpResponse(json.dumps(res), content_type="application/json")
        elif is_register == 0:
            res = {
                'Description': 'User does not exist.',
                'status': False,
            }
            return HttpResponse(json.dumps(res), content_type="application/json")


def get_user_information(request):
    data = json.loads(request.body)
    username = data['username']
    password = data['password']
    if username == '' or password == '':
        res = {
            'username': '',
            'totalPicture': 0,
            'isCovid': 0,
        }
        return HttpResponse(json.dumps(res), content_type="application/json")

    user = User.objects.filter(name=username)
    user_uuid = user[0].uuid
    if user.exists():
        pic = Picture.objects.filter(user__name=username)
        check_date_tmp = {}
        iscovid_date_tmp = {}
        normal_date_tmp = {}
        viral_date_tmp = {}
        for i in pic:
            date_str = str(i.check_date)[0:10]
            if date_str not in check_date_tmp:
                check_date_tmp[date_str] = 1
                iscovid_date_tmp[date_str] = 0
                normal_date_tmp[date_str] = 0
                viral_date_tmp[date_str] = 0
                if i.type == 'COVID':
                    iscovid_date_tmp[date_str] += 1
                if i.type == 'normal':
                    normal_date_tmp[date_str] += 1
                if i.type == 'viral':
                    viral_date_tmp[date_str] += 1
            else:
                check_date_tmp[date_str] += 1
                if i.type == 'COVID':
                    iscovid_date_tmp[date_str] += 1
                if i.type == 'normal':
                    normal_date_tmp[date_str] += 1
                if i.type == 'viral':
                    viral_date_tmp[date_str] += 1
        check_date = []
        iscovid_date = []
        normal_date = []
        viral_date = []
        for i in check_date_tmp:
            check_date.append(
                {'name': 'Total Check', 'check_date': i, 'amount': check_date_tmp[i]})
        for i in iscovid_date_tmp:
            iscovid_date.append(
                {'name': 'is Covid', 'check_date': i, 'amount': iscovid_date_tmp[i]})
        for i in normal_date_tmp:
            normal_date.append(
                {'name': 'Normal', 'check_date': i, 'amount': normal_date_tmp[i]})
        for i in viral_date_tmp:
            viral_date.append(
                {'name': 'Viral', 'check_date': i, 'amount': viral_date_tmp[i]})
        number_set = Picture.objects.filter(user_id=user_uuid)
        is_covid_number = 0
        normal_number = 0
        viral_number = 0
        for info in number_set:
            if info.type == 'COVID':
                is_covid_number += 1
            if info.type == 'normal':
                normal_number += 1
            if info.type == 'viral':
                viral_number += 1
        res = {
            'username': username,
            'totalPicture': len(number_set),
            'isCovid': is_covid_number,
            'normal': normal_number,
            'viral': viral_number,
            'check_date': check_date,
            'iscovid_date': iscovid_date,
            'normal_date': normal_date,
            'viral_date': viral_date,
        }
        return HttpResponse(json.dumps(res), content_type="application/json")


def get_my_history(request):
    """
        获取用户的检测历史
    """
    data = json.loads(request.body)
    username = data['username']
    password = data['password']
    if username == '' or password == '':
        return {}

    data = json.loads(request.body)
    username = data['username']
    pic_set = Picture.objects.filter(user__name=username)
    res = []
    for image in pic_set:
        res.append({
            'filename': image.pic.name,
            'imgUrl': image.pic_name,
            'isCovid': str(image.isCovid) + '(' + image.type + ')',
            'date': str(image.check_date),
            'patient': image.patient,
            'imgUUID': image.pic_uuid,
        })
    return HttpResponse(json.dumps(res), content_type="application/json")


def upload_covid_picture(request):
    """
        上传图片文件，然后判断传入的X光图片是什么性质
    """
    if request.FILES == None:
        return HttpResponse('Must have files attached')
    try:
        uid = request.POST['uid']
    except MultiValueDictKeyError:
        return None
    image = request.FILES.get('photo')
    patient = request.POST['patients']

    dir = str(request.POST['username']) + '\\' + str(image.name)
    set = User.objects.filter(name=request.POST['username'])
    if set.exists():
        pics = Picture.objects.filter(pic_name=image.name)
        if pics.exists():
            pic_exist_res = {
                'status': 200,
                'Descripition': 'Picture already existed. Check your history.'
            }
            return HttpResponse(json.dumps(pic_exist_res), content_type="application/json")
        filename, file_ext = os.path.splitext(image.name)
        # new_pic = Picture.objects.create(pic_uuid=uid, pic_name=str(uid) + file_ext, pic=image, user=set[0],
        #                                  isCovid=percent, patient=patient, type=itype)
        new_pic = Picture.objects.create(pic_uuid=uid, pic_name=str(
            uid) + file_ext, pic=image, user=set[0], patient=patient)
    else:
        return HttpResponse(json.dumps({'status': 404, 'Descripition': 'User does not exist.'}), content_type="application/json")
    os.replace('./PhotoDatabase/' + image.name.replace(' ', '_'),
               './PhotoDatabase/' + str(uid) + file_ext)
    print(os.path.exists('./PhotoDatabase/' + str(uid) + file_ext))
    ans = analysis('./PhotoDatabase/' + str(uid) + file_ext)
    itype, percent = ans.analysis_image()
    ans.get_feature(uid)
    myset = Picture.objects.filter(pic_uuid=uid)
    myset.update(isCovid=percent, type=itype)
    returnDate = myset[0].check_date
    # path = default_storage.save(dir, ContentFile(image.read()))
    # todo: 返回一个判断结果
    res = {
        'filename': image.name,
        'pred': itype + ' ' + '(' + str(percent) + ')',
        'status': 200,
        'check_date': str(returnDate),
        'patient_name': myset[0].patient,
    }
    del ans
    return HttpResponse(json.dumps(res), content_type="application/json")


def delete_picture(request):
    data = json.loads(request.body)
    username = data['username']
    uuid = data['uuid']
    pic_uuid = Picture.objects.filter(pic_uuid=uuid)[0].pic_uuid
    user_uuid = User.objects.filter(name=username)[0].uuid
    try:
        pic_uuid = Picture.objects.filter(pic_uuid=uuid)[0].pic_uuid
        user_uuid = User.objects.filter(name=username)[0].uuid
        Picture.objects.filter(user__uuid=user_uuid,
                               pic_uuid=pic_uuid).delete()
    except Exception:
        return HttpResponse(json.dumps({'message': 'Delete Error.'}), content_type="application/json")
    pic_set = Picture.objects.filter(user__name=username)
    res = []
    for image in pic_set:
        res.append({
            'filename': image.pic.name,
            'imgUrl': image.pic_name,
            'isCovid': str(image.isCovid),
            'date': str(image.check_date),
            'patient': image.patient,
        })
    return HttpResponse(json.dumps(res), content_type="application/json")
