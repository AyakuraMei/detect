from django.contrib import admin
from django.urls import path
from CovidDetect.views import *

app_name = 'coviddetect'

urlpatterns = [
    path('Detect/', upload_covid_picture),
    path('myHistory/', get_my_history),
    path('userInfo/', get_user_information),
    path('delete_picture/', delete_picture),
]
