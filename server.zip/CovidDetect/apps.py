from django.apps import AppConfig


class CoviddetectConfig(AppConfig):
    name = 'CovidDetect'
