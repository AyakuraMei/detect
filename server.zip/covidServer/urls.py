"""covidServer URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.urls.conf import include, re_path
from django.views import static
# from django.urls import include
from CovidDetect import views as detect_views
from django.conf.urls.static import static
from django.conf.urls import url
from .settings import MEDIA_ROOT, MEDIA_URL

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', detect_views.user_is_exist),
    path('home/', include('CovidDetect.urls', namespace='coviddetect'))
] + static(MEDIA_URL, document_root=MEDIA_ROOT)

    # path('home/Detect/', detect_views.upload_covid_picture),
    # path('home/myHistory/', detect_views.get_my_history),
    # path('home/userInfo/', detect_views.get_user_information),
    # path('home/delete_picture/', detect_views.delete_picture)