import React, { Component } from 'react'
import { Card, Statistic, Row, Col } from 'antd'
import { Bar } from 'ant-design-pro/lib/Charts'
import { G2, Chart, Tooltip, Interval, Axis, Coordinate, Interaction, getTheme } from "bizcharts";
import axios from 'axios'
import { connect } from 'react-redux'
import store from '../../redux/store'
import { showUser } from '../../redux/actions/userAction'
import { StarTwoTone, UserOutlined } from '@ant-design/icons';

export class User extends Component {
    state = {
        key: 'tab1',
    }

    componentWillMount() {
        console.log(this.props)
        this.props.showUser(store.getState().login.username, store.getState().login.password)
    }
    // todo: 加到查询中
    // componentDidMount(){
    //     axios.post('/User', {
    //         username: this.props.username, password: this.props.pw,
    //     }).then((response) => {
    //         // 返回一个obj，需要 parse 后获取 accuracy 和 已经上传的图像
    //     }).then((error) => {
    //         alert(error)
    //     })
    // }
    onTabChange = (key, type) => {
        this.setState({ key: key }, () => {})
    }

    render() {
        console.log(store.getState())
        const chartData = [...store.getState().user.response.data.check_date, ...store.getState().user.response.data.iscovid_date, ...store.getState().user.response.data.normal_date, ...store.getState().user.response.data.viral_date]
        const tabList = [
            {
                key: 'tab1', tab: '上传过的图片及识别结果',
            },
            {
                key: 'tab2', tab: '不同类型的检查结果占比',
            },
        ]
        let chart = <br></br>
        if (this.state.key === 'tab1') {
            chart = (
                <Card style={{ width: '100%' }} title={'用户名:       ' + this.props.user} tabList={tabList} onTabChange={this.onTabChange}>
                    <br></br>
                    <Row gutter={16}>
                        <Col span={12}>
                            <Statistic title={'总上传图片'} value={store.getState().user.response.data.totalPicture}></Statistic>
                        </Col>
                        <Col span={12}>
                            <Statistic title={'可能患病占比'} value={(store.getState().user.response.data.isCovid / store.getState().user.response.data.totalPicture).toFixed(2)}></Statistic>
                        </Col>
                    </Row>
                    <Chart height={400} padding="auto" data={chartData} autoFit>
                        <Interval
                            adjust={[
                                {
                                    type: 'dodge',
                                    marginRatio: 0,
                                },
                            ]}
                            color="name"
                            position="check_date*amount"
                        />
                        <Tooltip shared />
                    </Chart>
                </Card>)
        }
        else if (this.state.key === 'tab2') {
            const data = [
                {
                    item: 'COVID-19',
                    count: store.getState().user.response.data.isCovid,
                    percent: store.getState().user.response.data.isCovid / store.getState().user.response.data.totalPicture,
                },
                {
                    item: 'Normal',
                    count: store.getState().user.response.data.normal,
                    percent: store.getState().user.response.data.normal / store.getState().user.response.data.totalPicture,
                },
                {
                    item: 'Viral',
                    count: store.getState().user.response.data.viral,
                    percent: store.getState().user.response.data.viral / store.getState().user.response.data.totalPicture,
                },
            ]
            const cols = {
                percent: {
                    formatter: val => {
                        val = val * 100 + '%';
                        return val;
                    },
                },
            };
            chart = (
                <Card style={{ width: '100%' }} title={'用户名: ' + this.props.user} tabList={tabList} onTabChange={this.onTabChange}>
                    <Chart height={400} data={data} scale={cols} autoFit>
                        <Coordinate type="theta" radius={0.75} />
                        <Tooltip showTitle={false} />
                        <Axis visible={false} />
                        <Interval
                            position="percent"
                            adjust="stack"
                            color="item"
                            style={{
                                lineWidth: 1,
                                stroke: '#fff',
                            }}
                            label={['count', {
                                content: (data) => {
                                    return `${data.item}: ${data.percent * 100}%`;
                                },
                            }]}
                            state={{
                                selected: {
                                    style: (t) => {
                                        const res = getTheme().geometries.interval.rect.selected.style(t);
                                        return { ...res, fill: '#9B90C2' }
                                    }
                                }
                            }}
                        />
                        <Interaction type='element-single-selected' />
                    </Chart>
                </Card>
            )
        }
        return (
            <div>
                {chart}
            </div>
        )
    }
}

export default connect((state) => ({
    user: state.login.username,
    pw: state.login.password,
}), {
    showUser: showUser,
})(User)