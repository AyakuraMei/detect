import React, { Component } from 'react'
import './index.css'

export default class About extends Component {
    render() {
        return (
            <div className="about">
                <div className="Font-End">
                    <h1 className="title title--h1 title__separate">Web端:</h1>
                    <h2>React v17</h2>
                    <h2>Axios</h2>
                    <h2>Antd</h2>
                </div>
                <div className="Back-End">
                    <h1 className="title title--h1 title__separate">服务端:</h1>
                    <h2>Django</h2>
                    <h2>MySQL</h2>
                </div>
                <div className="Model">
                    <h1 className="title title--h1 title__separate">模型:</h1>
                    <h2>ResNet18</h2>
                </div>
            </div>
        )
    }
}
