import React, { Component } from 'react'
import { Link, Redirect } from 'react-router-dom'
import { Button, Input, Card } from 'antd'
import { UserOutlined, KeyOutlined } from '@ant-design/icons'
import { loginPost, registerPost } from '../../redux/actions/loginAction'
import { connect } from 'react-redux'
import './index.css'
import store from '../../redux/store'

class Login extends Component {
    sendMessage = () => {
        const { Username: { state: { value: user } } } = this
        const { Password: { state: { value: pw } } } = this
        this.props.loginUser(user, pw)
    }

    sendRegisterMessage = () => {
        const { Username: { state: { value: user } } } = this
        const { Password: { state: { value: pw } } } = this
        this.props.registerUser(user, pw)
    }

    render() {
        const { Meta } = Card
        return (
            <div className="page-login" >
                <Card className="LoginPadding">
                    <Input ref={c => { this.Username = c }} className="username" size="middle" placeholder="用户名" prefix={<UserOutlined />}></Input>
                    <Input ref={c => this.Password = c} className="password" size="middle" placeholder="密码" type="password" prefix={<KeyOutlined />}></Input>
                    <Button className="Login" value="Login" onClick={this.sendMessage} size="middle">登录 </Button>
                    <Button className="Register" value="Register" onClick={this.sendRegisterMessage} size="middle">注册</Button>
                    <Meta className="Meta" description={this.props.description}></Meta>
                </Card>
            </div>
        )
    }
}

export default connect((state) => ({
    response: state.login.response,
    user: state.login.username,
    pw: state.login.password,
    description: state.login.description,
    response: state.login.response
}), {
    loginUser: loginPost,
    registerUser: registerPost,
})(Login)