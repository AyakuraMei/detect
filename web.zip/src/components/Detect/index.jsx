import React, { Component } from 'react'
import { Upload, message, Card, Tooltip, Table, Input } from 'antd'
import { InboxOutlined, EditFilled } from '@ant-design/icons'
import axios from 'axios'
import { connect } from 'react-redux'
import store from '../../redux/store'
import { nanoid } from 'nanoid'

export class Detect extends Component {
    constructor(props) {
        super(props);
        this.state = {
            patient_now: '',
            uploaded: [
                {
                    // 'filename': 'example',
                    // 'pred': '0.114514',
                    // 'status': 200,
                    // 'check_date': '1919.08.10',
                    // 'patient_name': 'yjsp', 
                }
            ]
        };
        this.handleUpload = this.handleUpload.bind(this)
        this.handleUploadPatient = this.handleUploadPatient.bind(this)
    }

    handleUploadPatient(event) {
        this.setState({ patient_now: event.target.value }, () => { console.log(this.state) })
    }

    handleUpload(info) {
        // todo
        const { status } = info.file
        // 根据不同的上传状态确定信息
        if (status !== 'uploading') {
            console.log(info.file)
        }
        // 这里根据 response 内容显示（ hover 在上传的物件，会有相关的 response ）
        if (status === 'done') {
            message.success(`文件上传成功.`)
            this.setState({ uploaded: [...this.state.uploaded, info.file.response] }, () => { })
        }
        if (status === 'error') {
            // 需要处理的状态码为 500
            // 如果是 refuse 那么就不用理会，不加入到结果中
            message.error(`文件上传失败.`)
        }
    }

    componentDidMount() {
        console.log(this.props.user, this.props.pw)
    }

    render() {
        const { Dragger } = Upload
        const uploadProps = {
            name: '',
            multiple: false,
            // 根据 username 来确定上传的地址
            action: "http://localhost:8000/home/Detect/",
            accept: "image/png, image/jpeg, image/jpg",
            onChange: this.handleUpload,
        }
        const columns = [
            {
                title: '文件名',
                dataIndex: 'filename',
                key: 'filename',
                render: text => <a>{text}</a>
            },
            {
                title: '预测（置信度）',
                dataIndex: 'pred',
                key: 'pred',
            },
            {
                title: '检查日期',
                dataIndex: 'check_date',
                key: 'check_date',
            },
            {
                title: '病人姓名',
                dataIndex: 'patient_name',
                key: 'patient_name',
            }
        ]

        const title = 'Input a Patients Name'

        return (
            <div className="site-card-border-less-wrapper">
                <Dragger {...uploadProps}
                    data={(file) => {
                        if (this.state.patient_now === '') {
                            message.error('病人姓名不可谓空')
                            return
                        } else {
                            return {
                                username: this.props.user,
                                password: this.props.pw,
                                photo: file,
                                uid: nanoid(),
                                patients: this.state.patient_now,
                            }
                        }
                    }}>
                    <p className="ant-upload-drag-icon">
                        <InboxOutlined />
                    </p>
                    <p className="ant-upload-text">点击或拖拉上传</p>
                    <p className="ant-upload-hint">（仅支持单个图片上传）</p>
                </Dragger>
                <Tooltip trigger={['focus']} title={title} placement="topLeft" overlayClassName="patients">
                    <Input prefix={<EditFilled />} placeholder="病人姓名" onChange={this.handleUploadPatient} maxLength={25}>
                    </Input>
                </Tooltip>
                <br></br>
                <br></br>
                <br></br>
                <div className="site-card-border-less-wrapper">
                    <Table columns={columns} dataSource={this.state.uploaded}></Table>
                </div>
            </div>
        )
    }
}

export default connect((state) => ({
    user: state.login.username,
    pw: state.login.password,
}))(Detect)