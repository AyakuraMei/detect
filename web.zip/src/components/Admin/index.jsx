import React, { Component } from 'react'
import { Layout, Menu} from 'antd'
import { CloseOutlined, SearchOutlined } from '@ant-design/icons';
import { withRouter } from 'react-router-dom'
const { Header, Content, Sider } = Layout

@withRouter
class Admin extends Component {
    go = ({ item, key, path, domEvent }) => {
        this.props.history.push(key)
    }
    render() {
        return (
            <Layout>
                <Header className="header">
                <SearchOutlined style={{color: 'white'}} />
                {/* 记得改这个 header */}
                </Header>
                <Layout>
                    <Sider width={200} style={{ background: '#fff' }}>
                        <Menu mode='inline' defaultSelectedKeys={['1']} defaultOpenKeys={['sub1']} style={{ height: '100%', borderRight: 0 }}>
                            <Menu.Item key="/home/Detect" onClick={this.go}>检测识别</Menu.Item>
                            <Menu.Item key="/home/MyHistory" onClick={this.go}>检测历史</Menu.Item>
                            <Menu.Item key="/home/UserInfo" onClick={this.go}>统计信息</Menu.Item>
                            <Menu.Item key="/home/About" onClick={this.go}>关于本网站</Menu.Item>
                        </Menu>
                    </Sider>
                    <Layout style={{padding: '0 24px 24px'}}>
                        <Content style={{background: '#fff', padding: 24, margin: 0, minHeight:280}}>
                            {this.props.children}
                        </Content>
                    </Layout>
                </Layout>
            </Layout>
        )
    }
}

export default Admin
