import React, { Component } from 'react'
import { List, Avatar, Space, message, Button, Input, Divider, Image } from 'antd';
import { MessageOutlined, LikeOutlined, StarOutlined, CloseOutlined } from '@ant-design/icons';
import { connect } from 'react-redux';
import { getMyHistory } from '../../redux/actions/historyAction'
import store from '../../redux/store'
import axios from 'axios';
import './index.css'

export class MyHistory extends Component {
    // items: 装载返回的信息用，其中包含文件 文件名 检查日期 参考用判断结果
    constructor(props) {
        super(props);
        this.state = {
            items: [],
            oldItems: [],
            searchBar: '',
        };
        this.onSearch = this.onSearch.bind(this)
    }
    componentWillMount() {
        // todo: 如果无法解决就在外部写
        axios.post('http://localhost:8000/home/myHistory/', {
            username: store.getState().login.username,
            password: store.getState().login.password,
        }).catch((error) => {
            message.error('获得历史信息失败')
        }).then((response) => {
            this.setState({ items: [...response.data], oldItems: [...response.data] }, () => { })
        })
    }

    componentWillUnmount() {
        this.setState = (state, callback) => {
            return;
        }
    }

    deletePicture(imgUrl) {
        let delete_uuid = imgUrl.split('.')[0]
        console.log(store.getState().login.username, delete_uuid)
        axios.post('http://localhost:8000/home/delete_picture/', {
            username: store.getState().login.username,
            uuid: delete_uuid,
        }).catch((error) => {
            message.error(error)
        }).then((response) => {
            this.setState({ oldItems: [...response.data] }, () => { })
            var items = []
            for (var i = 0; i < this.state.oldItems.length; i++) {
                if (this.state.oldItems[i].patient.indexOf(this.state.searchBar) >= 0) {
                    items.push(this.state.oldItems[i])
                }
            }
            this.setState({ items: items }, () => { })
        })
    }

    onSearch = (event) => {
        this.setState({ searchBar: event.target.value })
        if (event.target.value === '') {
            this.setState({ items: this.state.oldItems }, () => { })
            return
        }
        var items = []
        for (var i = 0; i < this.state.oldItems.length; i++) {
            if (this.state.oldItems[i].patient.indexOf(event.target.value) >= 0) {
                items.push(this.state.oldItems[i])
            }
        }
        this.setState({ items: items }, () => { })
    }

    render() {
        const { Search } = Input
        return (
            <div>
                {/* test */}
                {/* <img src="http://localhost:8000/PhotoDatabase/hvick225/wallpaper_1.png"></img> */}
                <Input placeholder="输入病人姓名..." allowClear style={{ width: 400 }} enterButton="Search" size="large" onChange={this.onSearch} />
                <Divider></Divider>
                <List
                    itemLayout="vertical"
                    size="large"
                    pagination={{
                        onChange: page => {
                            console.log(page);
                        },
                        pageSize: 6,
                    }}
                    dataSource={this.state.items}
                    renderItem={item => (
                        <List.Item
                            key={item.imgUrl}
                            extra={
                                <Image.PreviewGroup>
                                    <Image
                                        width={272}
                                        alt={item.imgUrl}
                                        src={'http://localhost:8000/PhotoDatabase/' + item.imgUrl}
                                        width={200}
                                    />
                                    <Image
                                        width={200}
                                        src={'http://localhost:8000/PhotoDatabase/feature/' + item.imgUUID + '_cv2.png'}
                                    />
                                </Image.PreviewGroup>
                            }
                        >
                            <List.Item.Meta
                                title={<a>{item.filename}</a>}
                                description={'病人姓名: ' + item.patient}
                            />
                            <div>
                                <p>特征提取:</p>
                                {/* <Image
                                    width={200}
                                    src={'http://localhost:8000/PhotoDatabase/feature/' + item.imgUUID + '_cv2.png'}
                                /> */}
                                {/* <img height={100} width={100} alt={'feature:' + item.filename} src={'http://localhost:8000/PhotoDatabase/feature/' + item.imgUUID + '_cv2.png'}></img> */}
                            </div>
                            <br></br>
                            {'判断（置信度）: ' + item.isCovid}
                            <br></br>
                            <br></br>
                            {'检查日期: ' + item.date}
                            <br></br>
                            <br></br>
                            <Button type="primary" danger onClick={() => this.deletePicture(item.imgUrl)}>删除</Button>
                        </List.Item>
                    )}
                />
            </div>
        )
    }
}

export default connect((state) => ({
    // 获取 response 中返回的 data
    // items: state.history.response.data.items
}, {
    getHistory: getMyHistory,
}))(MyHistory)