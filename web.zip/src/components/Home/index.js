import React, { Component } from 'react'
import '../../App'
import { secondRoutes } from '../../Router'
import { Route, Redirect } from 'react-router-dom'
// import PubSub from 'pubsub-js'
// import { USERINFO } from '../pubsub'
import Admin from '../Admin'
import { connect } from 'react-redux'
import store from '../../redux/store'

// second routes
export class Home extends Component {
  state = {
    username: '',
    password: '',
  }

  render() {
    return (
      <div className="App">
        <Admin>
          {
            secondRoutes.map((item) => {
              return <Route key={item.path} path={item.path} component={item.component} {...this.props.status}></Route>
            })
          }
          <Redirect from="/home" to="/home/Detect" exact></Redirect>
        </Admin>
      </div>
    );
  }
}

export default connect((state) => ({
  status: { user: state.login.username, pw: state.login.password }
}))(Home)