import React, { Component } from 'react'

export default class NotFound extends Component {
    render() {
        return (
            <h2>Not Found</h2>
        )
    }
}
