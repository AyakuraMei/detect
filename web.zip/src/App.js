import React, { Component } from 'react'
import axios from 'axios'
import './App.css'

axios.defaults.withCredentials = true
axios.defaults.headers.post['Content-Type'] = 'application/json'

// second routes
export default class App extends Component {
  render() {
    return ;
  }
}
