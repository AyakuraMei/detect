import {USER_INFORMATION} from '../constants'

const initialState = {
    username: '',
    totalCheck: '',
    accuracy: '',
}

export default function userReducer(preState = initialState, action){
    const {type, response} = action
    switch(type){
        case USER_INFORMATION:
            return {
                ...preState, response: response,
            }
        default:
            return preState
    }
}