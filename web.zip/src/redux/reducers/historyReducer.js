import { SHOW_MY_HISTORY } from '../constants'

const initialState = {
    data: [{
        filename: '',
        img: '',
        isCovid: '',
        date: '',
    }],
}

export default function historyReducer(preState = initialState, action) {
    const { type, response } = action
    switch(type){
        case SHOW_MY_HISTORY:
            return {
                // 将 response 返回的历史记录存到 state 的 history 数组中
                ...preState, data: response.data.history,
            }
        default:
            return preState
    }
}

