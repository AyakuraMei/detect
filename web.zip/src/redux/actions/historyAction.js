import { SHOW_MY_HISTORY } from '../constants'
import axios from 'axios'
import store from '../store'

export const getMyHistory = (username, password) => {
    return () => {
        axios.post('http://127.0.0.1:8000/home/userInfo/', {
            username: store.getState().login.username,
            password: store.getState().login.password,
        }).then((response) => {
            console.log('history', response.data)
            if (response.data.status === 200){
                store.dispatch({
                    type: SHOW_MY_HISTORY, response: response,
                })
            }
        })
    }
}