import { USER_INFORMATION } from '../constants'
import store from '../store'
import axios from 'axios'

export const showUser = (username, password) => {
    return () => {
        axios.post('http://127.0.0.1:8000/home/userInfo/', {
            username: username,
            password: password,
        }).catch((error) => {
            console.log(error)
        }).then((response) => {
            console.log('user action')
            if (response.status === 200) {
                store.dispatch({
                    // 存储了用户的个人信息
                    type: USER_INFORMATION, response: response,
                })
            }
        })
    }
}